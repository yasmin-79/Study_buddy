import React from 'react';
import { Link } from 'react-router-dom';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';

const data = [
  { name: 'Math', value: 40 },
  { name: 'Science', value: 30 },
  { name: 'English', value: 20 },
  { name: 'History', value: 10 },
];
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

function Dashboard() {
  return (
    <div className="p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Link to="/" className="bg-red-500 text-white px-4 py-2 rounded">Logout</Link>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white shadow p-6 rounded-2xl">
          <h2 className="text-lg font-semibold mb-3">Study Progress</h2>
          <PieChart width={300} height={300}>
            <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </div>
        <div className="bg-white shadow p-6 rounded-2xl">
          <h2 className="text-lg font-semibold mb-3">Announcements</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>Group meeting at 5 PM</li>
            <li>Submit assignment by Friday</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;