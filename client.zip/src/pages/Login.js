import React from 'react';
import { Link } from 'react-router-dom';

function Login() {
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-cyan-400/20 to-purple-600/20">
      <div className="bg-white p-8 rounded-2xl shadow-md w-96">
        <h1 className="text-2xl font-bold mb-4 text-center">Login</h1>
        <input className="w-full p-2 border rounded mb-3" placeholder="Email" />
        <input className="w-full p-2 border rounded mb-3" placeholder="Password" type="password" />
        <button className="w-full bg-cyan-500 text-white py-2 rounded hover:bg-cyan-600">Login</button>
        <p className="text-sm text-center mt-3">Don't have an account? <Link to="/register" className="text-cyan-600">Register</Link></p>
      </div>
    </div>
  );
}

export default Login;