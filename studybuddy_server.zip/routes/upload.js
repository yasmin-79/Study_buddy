import express from 'express';
import multer from 'multer';
import path from 'path';
import pool from '../db.js';
import { fileURLToPath } from 'url';

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ storage, limits: { fileSize: 30*1024*1024 }, fileFilter: (req,file,cb)=> {
  if (file.mimetype === 'application/pdf') cb(null,true);
  else cb(new Error('Only PDFs allowed'));
}});

router.post('/', upload.single('pdf'), async (req,res)=> {
  try {
    const { title, subject, userId } = req.body;
    if (!req.file) return res.status(400).json({ message: 'No file' });
    const result = await pool.query('INSERT INTO files (title,subject,filename,uploaded_by) VALUES ($1,$2,$3,$4) RETURNING *', [title||req.file.originalname, subject||'General', req.file.filename, userId||null]);
    res.json({ message: 'Uploaded', file: result.rows[0] });
  } catch (err) { console.error(err); res.status(500).json({ message: 'Upload failed' }); }
});

export default router;
