import express from 'express';
import pool from '../db.js';

const router = express.Router();

router.get('/', async (req,res)=> {
  try {
    const { subject } = req.query;
    let q = `SELECT f.id,f.title,f.subject,f.filename,u.name AS uploaded_by,f.uploaded_at FROM files f LEFT JOIN users u ON f.uploaded_by = u.id`;
    const params = [];
    if (subject) { q += ' WHERE f.subject = $1'; params.push(subject); }
    q += ' ORDER BY f.uploaded_at DESC';
    const result = await pool.query(q, params);
    res.json(result.rows);
  } catch (err) { console.error(err); res.status(500).json({ message: 'Fetch failed' }); }
});

export default router;
