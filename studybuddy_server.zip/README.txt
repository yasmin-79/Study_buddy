StudyBuddy server

How to run:
1. Create .env in this folder (see .env.example)
2. Install dependencies:
   npm install
   # If multer ETARGET error occurs: npm install multer@1.4.5-lts.1 --save
3. Create DB and run init_tables.sql (or use Neon DB and set DATABASE_URL)
4. Start server: node server.js
